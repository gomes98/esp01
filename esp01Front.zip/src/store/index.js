import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
import snackbar from './snackbar'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    stateEvents: false,
    gpio1: false,
    gpio2: false,
    in1: false,
    in2: false,
  },
  mutations: {
    setGpio1(state, payload) {
      state.gpio1 = payload
    },
    setGpio2(state, payload) {
      state.gpio2 = payload
    },
    setIn1(state, payload) {
      state.in1 = payload
    },
    setIn2(state, payload) {
      state.in2 = payload
    },
    setStateEvents(state, payload) {
      state.stateEvents = payload
    }
  },
  actions: {
    setGpio1S(context, payload){
      context.commit('setGpio1', payload)
    },
    setIn1(context, payload){
      context.commit('setIn1', payload)
    },
    setIn2(context, payload){
      context.commit('setIn2', payload)
    },
    setGpio2S(context, payload){
      context.commit('setGpio2', payload)
    },
    setGpio1(context, payload) {
      let formData = new FormData();
      formData.append("gpio1", payload);
      axios.post(`/gpio`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
        .then(() => {
          context.commit('setGpio1', payload)
        });
    },
    setGpio2(context, payload) {
      let formData = new FormData();
      formData.append("gpio2", payload);
      axios.post(`/gpio`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
        .then(() => {
          context.commit('setGpio2', payload)
        });
    },
    loadGpio(context) {
      axios(`/gpio` )
        .then((resp) => {

          context.commit('setGpio1', resp.data.gpio1)
          context.commit('setGpio2', resp.data.gpio2)
        });
    },
    setStateEvents(context, payload) {
      context.commit('setStateEvents', payload)
    },
  },
  getters: {
    getGpio1(state) {
      return state.gpio1
    },
    getGpio2(state) {
      return state.gpio2
    },
    getIn1(state) {
      return state.in1
    },
    getIn2(state) {
      return state.in2
    },
    getStateEvents(state) {
      return state.stateEvents
    },

  },
  modules: {
    snackbar
  }
})
