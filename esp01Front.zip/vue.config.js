module.exports = {
  transpileDependencies: [
    'vuetify'
  ],

  productionSourceMap: false
}
